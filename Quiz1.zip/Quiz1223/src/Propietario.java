public class Propietario extends Persona {
    private String idPropietario;

    public Propietario(String nombres, String apellidos, String documento, int edad, String idPropietario) {
        super(nombres, apellidos, documento, edad);
        this.idPropietario = idPropietario;
    }

    public String getIdPropietario() {
        return idPropietario;
    }

    public Object[] obtenerInformacionPropietario() {
        Object[] info = {getNombres(), getApellidos(), getEdad(), getDocumento(), getIdPropietario()};
        return info;
    }
}
