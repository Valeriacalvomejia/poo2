import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class PropietarioGUI extends JFrame {
    private ArrayList<Propietario> propietarios;
    private JTextField nombresField, apellidosField, documentoField, edadField, idField;
    private JTextArea outputArea;

    public PropietarioGUI() {
        propietarios = new ArrayList<>();

        JLabel nombresLabel = new JLabel("Nombres:");
        nombresField = new JTextField(20);
        JLabel apellidosLabel = new JLabel("Apellidos:");
        apellidosField = new JTextField(20);
        JLabel documentoLabel = new JLabel("Documento:");
        documentoField = new JTextField(20);
        JLabel edadLabel = new JLabel("Edad:");
        edadField = new JTextField(5);
        JLabel idLabel = new JLabel("ID Propietario:");
        idField = new JTextField(10);

        JButton agregarButton = new JButton("Agregar Propietario");
        agregarButton.addActionListener(e -> agregarPropietario());

        JButton listarButton = new JButton("Listar Propietarios");
        listarButton.addActionListener(e -> listarPropietarios());

        JButton buscarButton = new JButton("Buscar Propietario");
        buscarButton.addActionListener(e -> buscarPropietario());

        outputArea = new JTextArea(10, 40);
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(7, 2));
        panel.add(nombresLabel);
        panel.add(nombresField);
        panel.add(apellidosLabel);
        panel.add(apellidosField);
        panel.add(documentoLabel);
        panel.add(documentoField);
        panel.add(edadLabel);
        panel.add(edadField);
        panel.add(idLabel);
        panel.add(idField);
        panel.add(agregarButton);
        panel.add(listarButton);
        panel.add(buscarButton);

        Container container = getContentPane();
        container.add(panel, BorderLayout.NORTH);
        container.add(scrollPane, BorderLayout.CENTER);

        setTitle("Gestión de Propietarios");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void agregarPropietario() {
        try {
            String nombres = nombresField.getText();
            String apellidos = apellidosField.getText();
            String documento = documentoField.getText();
            int edad = Integer.parseInt(edadField.getText());
            String idPropietario = idField.getText();

            Propietario propietario = new Propietario(nombres, apellidos, documento, edad, idPropietario);
            propietarios.add(propietario);

            outputArea.append("Propietario agregado:\n" +
                    "Nombres: " + nombres + "\n" +
                    "Apellidos: " + apellidos + "\n" +
                    "Documento: " + documento + "\n" +
                    "Edad: " + edad + "\n" +
                    "ID Propietario: " + idPropietario + "\n\n");

            // Limpiar campos después de agregar
            nombresField.setText("");
            apellidosField.setText("");
            documentoField.setText("");
            edadField.setText("");
            idField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese una edad válida.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void listarPropietarios() {
        outputArea.setText("");
        for (Propietario propietario : propietarios) {
            Object[] info = propietario.obtenerInformacionPropietario();
            outputArea.append("Nombres: " + info[0] + "\n" +
                    "Apellidos: " + info[1] + "\n" +
                    "Edad: " + info[2] + "\n" +
                    "Documento: " + info[3] + "\n" +
                    "ID Propietario: " + info[4] + "\n\n");
        }
    }

    private void buscarPropietario() {
        outputArea.setText("");
        String idBuscado = idField.getText();
        boolean encontrado = false;
        for (Propietario propietario : propietarios) {
            if (propietario.getIdPropietario().equals(idBuscado)) {
                Object[] info = propietario.obtenerInformacionPropietario();
                outputArea.append("Nombres: " + info[0] + "\n" +
                        "Apellidos: " + info[1] + "\n" +
                        "Edad: " + info[2] + "\n" +
                        "Documento: " + info[3] + "\n" +
                        "ID Propietario: " + info[4] + "\n\n");
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            outputArea.append("Propietario con ID " + idBuscado + " no encontrado.\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PropietarioGUI());
    }
}

